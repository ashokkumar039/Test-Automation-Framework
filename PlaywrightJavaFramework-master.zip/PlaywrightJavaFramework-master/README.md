# PlaywrightJavaFramework

Following features are used in Framework:
- Page Object Model Design Pattern
- Maven build management
- Extent Reporting with base64 screenshots
- TestNG - TDD structure/approach 
- Playwright as Testing tool
- Json Data Driven
- TestNG Data Driven

Description for Framework - 

![framework structure japneet](https://user-images.githubusercontent.com/46420079/214802447-2ded5fd5-0bf2-4567-a98a-55f655ea04c9.png)
