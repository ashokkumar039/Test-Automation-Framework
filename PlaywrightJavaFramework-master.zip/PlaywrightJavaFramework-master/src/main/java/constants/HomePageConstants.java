package constants;

public class HomePageConstants
{
    public static final String HOME_PAGE_TITLE = "Your Store";
}
