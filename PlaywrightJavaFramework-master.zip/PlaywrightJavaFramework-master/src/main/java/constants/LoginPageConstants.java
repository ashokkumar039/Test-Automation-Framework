package constants;

public class LoginPageConstants
{
    public static final String EMAIL = "viper@mailinator.com";
    public static final String PASSWORD = "viper";
}
