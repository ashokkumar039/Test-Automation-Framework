# PythonRestApiTesting
Rest Api Testing using Requests Module in Python with PyTest

To test rest-api - 
1) Requests module 
2) PyTest
3) Python
4) Allure report
5) Config.ini
6) Data Driven Testing
7) Csv Data
