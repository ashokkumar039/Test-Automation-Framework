# Login page locators

email_text="id:input-email"
pswd_text="id:input-password"
login_btn="xpath://input[@value='Login']"